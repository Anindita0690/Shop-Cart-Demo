/** JavaScript code for Food Mart **/

$(document).ready(function() {
	$("ul.product-list").css("column-count", 3);
});

var myApp = angular.module('myApp', []);

myApp.controller('myController', function($scope, $http) {
	
	if (localStorage.getItem("cart")) {
		$scope.cart = JSON.parse(localStorage.getItem("cart"));
	} else {
		$scope.cart = [];
	}


	// load data from json
	$http.get('data.json').success(function(response) {
		$scope.myData = response;
	});

	$scope.addToCart = function(product) {
		var found = false;
		$scope.cart.forEach(function(item) {
			if (item.prodName === product.prodName) {
				item.quantity++;
				found = true;
			}
		});
		if (!found) {
			$scope.cart.push(angular.extend({
				quantity : 1
			}, product));
		}
		localStorage.setItem("cart", JSON.stringify($scope.cart));
	};

	$scope.deleteItem = function(product) {
		$scope.cart.forEach(function(item) {
			if ((item.prodName === product.prodName) && item.quantity !== 0) {
				item.quantity--;

				if (item.quantity === 0) {
					$scope.cart.splice($scope.getIndex(item), 1);
				}
			}
		});
		localStorage.setItem("cart", JSON.stringify($scope.cart));
	};

	$scope.removefromCart = function(index) {
		$scope.cart.splice(index, 1);
		localStorage.setItem("cart", JSON.stringify($scope.cart));
	};

	$scope.getCartPrice = function() {
		var total = 0;
		$scope.cart.forEach(function(product) {
			total += product.cost * product.quantity;
		});
		return total;
	};

	$scope.cartContains = function(product) {
		var found = false;
		$scope.cart.forEach(function(item) {
			if (item.prodName === product.prodName) {
				found = true;
			}
		});
		return found;
	}

	$scope.getIndex = function(product) {
		for (var c = 0; c < $scope.cart.length; c++) {
			if ($scope.cart[c].prodName == product.prodName) {
				return c;
			}
		}
	}
});
